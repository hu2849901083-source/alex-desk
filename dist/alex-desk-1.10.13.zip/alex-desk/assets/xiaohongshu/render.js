const path = require("path");
const { pathToFileURL } = require("url");
const { chromium } = require("playwright");

(async () => {
  const root = __dirname;
  const browser = await chromium.launch({
    headless: true,
    executablePath: "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  });
  const page = await browser.newPage({
    viewport: { width: 1242, height: 1660 },
    deviceScaleFactor: 1,
  });

  await page.goto(pathToFileURL(path.join(root, "design.html")).href);
  await page.evaluate(() => document.fonts.ready);

  for (let i = 1; i <= 4; i += 1) {
    await page.locator(`#page-${i}`).screenshot({
      path: path.join(root, `alex-desk-xhs-0${i}.png`),
    });
  }

  await browser.close();
})();
